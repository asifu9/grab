package com.test.grab;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.test.grab.domain.Domain;

@Service
public class RestTemplateImpl implements IRestTemplate {

	@Autowired
	private RestTemplate restTemplate;
	
	@Override
	public Object getData(String url,Class classType) throws Exception {
		System.out.println("url " + url);
		return  restTemplate.getForEntity(url, classType).getBody();
	}

	
}
