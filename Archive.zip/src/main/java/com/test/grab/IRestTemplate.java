package com.test.grab;

import java.awt.List;

import org.springframework.stereotype.Component;

import com.test.grab.domain.Domain;

public interface IRestTemplate {

	Object getData(String url,Class classType) throws Exception;
}
