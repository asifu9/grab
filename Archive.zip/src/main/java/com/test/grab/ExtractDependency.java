package com.test.grab;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.CopyOnWriteArrayList;
import java.util.concurrent.Executor;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.test.grab.domain.NpmMetaData;

@Component
public class ExtractDependency {
	
	@Autowired
	IRestTemplate template;
	
	
	Set<String> result = new HashSet<>();
	public int getAllDependencies(String packageName){
		try {
			
			findInDepth(packageName);
			
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		return result.size();
		
	}
	private void findInDepth(String packageName) throws Exception{
		NpmMetaData data=  null;
		try{
		 data=  (NpmMetaData) template.getData(String.format("http://registry.npmjs.org/%s/latest",packageName),NpmMetaData.class);
		}catch(Exception ex){
			ex.printStackTrace();
		}

		if(data!=null && data.getDependencies()!=null ){
			
			data.getDependencies().keySet().forEach(child->{
				if(!result.contains(child)){
					result.add(child);
					try {
						findInDepth(child);
					} catch (Exception e) {
						e.printStackTrace();
					}
				}
			});
		}
	
	}
	
	
}
