package com.test.grab.domain;

public class Domain {

}
