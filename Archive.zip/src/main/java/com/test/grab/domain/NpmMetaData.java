package com.test.grab.domain;


import java.util.List;
import java.util.Map;

public class NpmMetaData extends Domain{
	private String name;
	private String description;
	private Map<String,Object> author;
	private Map<String,Object> repository;
	private Map<String,Object> dependencies; 
	private Map<String,Object> devDependencies;
	List<String> keywords;
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public Map<String, Object> getAuthor() {
		return author;
	}
	public void setAuthor(Map<String, Object> author) {
		this.author = author;
	}
	public Map<String, Object> getRepository() {
		return repository;
	}
	public void setRepository(Map<String, Object> repository) {
		this.repository = repository;
	}
	public Map<String, Object> getDependencies() {
		return dependencies;
	}
	public void setDependencies(Map<String, Object> dependencies) {
		this.dependencies = dependencies;
	}
	public Map<String, Object> getDevDependencies() {
		return devDependencies;
	}
	public void setDevDependencies(Map<String, Object> devDependencies) {
		this.devDependencies = devDependencies;
	}
	public List<String> getKeywords() {
		return keywords;
	}
	public void setKeywords(List<String> keywords) {
		this.keywords = keywords;
	}
	@Override
	public String toString() {
		return "NpmMetaData [dependencies=" + dependencies + "]";
	}
	
	/**
	 * {
	"name": "cliff",
	"description": "Your CLI formatting friend.",
	"version": "0.1.10",
	"author": {
		"name": "Charlie Robbins",
		"email": "charlie.robbins@gmail.com"
	},
	"repository": {
		"type": "git",
		"url": "http://github.com/flatiron/cliff.git"
	},
	"keywords": ["cli", "logging", "tools", "winston"],
	"dependencies": {
		"colors": "~1.0.3",
		"eyes": "~0.1.8",
		"winston": "0.8.x"
	},
	"devDependencies": {
		"vows": "0.8.x"
	},
	"main": "./lib/cliff",
	"scripts": {
		"test": "vows test/*-test.js --spec"
	},
	"engines": {
		"node": ">= 0.4.0"
	},
	"gitHead": "3baf40a73432a26303f080176c7d13fe293bc1d8",
	"bugs": {
		"url": "https://github.com/flatiron/cliff/issues"
	},
	"homepage": "https://github.com/flatiron/cliff",
	"_id": "cliff@0.1.10",
	"_shasum": "53be33ea9f59bec85609ee300ac4207603e52013",
	"_from": ".",
	"_npmVersion": "2.1.9",
	"_nodeVersion": "0.10.33",
	"_npmUser": {
		"name": "indexzero",
		"email": "charlie.robbins@gmail.com"
	},
	"maintainers": [{
		"name": "indexzero",
		"email": "charlie.robbins@gmail.com"
	}, {
		"name": "jcrugzz",
		"email": "jcrugzz@gmail.com"
	}],
	"dist": {
		"shasum": "53be33ea9f59bec85609ee300ac4207603e52013",
		"tarball": "https://registry.npmjs.org/cliff/-/cliff-0.1.10.tgz"
	},
	"directories": {}
}
	 */
	
}
